import 'package:flutter/material.dart';
// Assuming specific exceptions exist or we parse strings.
// Assuming specific exceptions exist or we parse strings.
// Ideally we should have custom exceptions. For now we might parse strings or dynamic errors.
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../constants/app_colors.dart';

class AppErrorHandler {
  static String getErrorMessage(BuildContext context, dynamic error) {
    final l10n = AppLocalizations.of(context)!;
    final errorString = error.toString();

    // Map specific error codes or strings to L10n
    if (errorString.contains('user-not-found') ||
        errorString.contains('User not found')) {
      return l10n.errorUserNotFound;
    }
    if (errorString.contains('wrong-password') ||
        errorString.contains('Invalid credentials')) {
      return l10n.errorInvalidCredentials;
    }
    if (errorString.contains('email-already-in-use') ||
        errorString.contains('Username exists')) {
      return l10n.errorUsernameExists;
    }
    if (errorString.contains('weak-password')) {
      return l10n.errorWeakPassword;
    }
    if (errorString.contains('network-request-failed')) {
      return l10n.errorNetwork;
    }
    if (errorString.contains('permission-denied')) {
      return l10n.errorPermissionDenied;
    }

    // Fallback for custom codes (if we start using them)
    if (errorString == 'errorDeviceMismatch') return l10n.errorDeviceMismatch;
    if (errorString == 'errorMaterialNotFound') {
      return l10n.errorMaterialNotFound;
    }
    if (errorString == 'errorUnknown' || errorString.contains('errorUnknown')) {
      return l10n.errorUnknown;
    }
    if (errorString == 'errorSubjectNotFound' ||
        errorString.contains('errorSubjectNotFound')) {
      return l10n.errorSubjectNotFound;
    }
    if (errorString == 'errorContentNotFound' ||
        errorString.contains('errorContentNotFound')) {
      return l10n.errorContentNotFound;
    }
    if (errorString == 'errorFieldRequired' ||
        errorString.contains('errorFieldRequired')) {
      return l10n.errorFieldRequired;
    }

    // Default
    return errorString.replaceAll(
        'Exception: ', ''); // Return raw if no match, or l10n.errorUnknown
  }

  static void showErrorToast(BuildContext context, dynamic error) {
    final message = getErrorMessage(context, error);
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.BOTTOM,
      timeInSecForIosWeb: 3,
      backgroundColor: AppColors.error,
      textColor: Colors.white,
      fontSize: 16.0,
    );
  }

  static void showSuccessToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      timeInSecForIosWeb: 2,
      backgroundColor: Colors.green,
      textColor: Colors.white,
      fontSize: 16.0,
    );
  }

  // Helper to standardise error handling in Providers
  static String parseError(dynamic e) {
    // This returns a "code" or a raw string that getErrorMessage can parse.
    // For simplicity, we just return the string since getErrorMessage parses strings.
    return e.toString();
  }
}
